import React from 'react';

function About() {
  return (
    <section className="pt-20 md:pt-32 pb-16 md:pb-32 bg-gray-50 px-4">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8">About Me</h2>
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <p className="text-lg text-gray-600 mb-6">
              Hi, I'm Arun kumar KM. With over 2 years of experience in web development, I've helped numerous businesses 
              establish their online presence and create impactful digital solutions. My passion 
              lies in crafting clean, efficient code and delivering exceptional user experiences.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              I specialize in full-stack development using modern technologies and best practices. 
              Whether it's building responsive frontends with React or designing scalable backend 
              systems, I ensure that every project meets the highest standards of quality and performance.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-4">Technical Skills</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-medium mb-2">Frontend</h4>
                <ul className="text-gray-600">
                  <li>React</li>
                  <li>TypeScript</li>
                  <li>Tailwind CSS</li>
                  <li>Next.js</li>
                </ul>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-medium mb-2">Backend</h4>
                <ul className="text-gray-600">
                  <li>Node.js</li>
                  <li>Express</li>
                  <li>PostgreSQL</li>
                  <li>REST APIs</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;