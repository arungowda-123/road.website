import React from 'react';

function Services() {
  const services = [
    {
      id: 1,
      title: 'Web Development',
      description: 'Custom websites and web applications built with modern technologies and best practices.',
      features: ['Responsive Design', 'Performance Optimization', 'SEO-friendly', 'Modern UI/UX']
    },
    {
      id: 2,
      title: 'Frontend Development',
      description: 'Beautiful, interactive user interfaces that engage and convert visitors.',
      features: ['React Applications', 'Single Page Apps', 'Progressive Web Apps', 'Animation & Interaction']
    },
    {
      id: 3,
      title: 'Backend Development',
      description: 'Scalable server solutions and APIs that power your applications.',
      features: ['REST APIs', 'Database Design', 'Authentication', 'Performance Optimization']
    }
  ];

  return (
    <section className="pt-20 md:pt-32 pb-16 md:pb-32 px-4">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8">Services</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div key={service.id} className="bg-white p-6 rounded-xl shadow-lg">
              <h3 className="text-xl font-semibold mb-4">{service.title}</h3>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <ul className="space-y-2">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-gray-700">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Services;