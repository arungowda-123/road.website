import React from 'react';
import { Github, Linkedin, Mail } from 'lucide-react';

function Home() {
  return (
    <section className="pt-20 md:pt-32 pb-16 md:pb-32 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Hi, I'm Arun kumar KM
              <span className="block text-blue-600">Full Stack Developer</span>
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              I build beautiful, user-friendly websites and applications that deliver results. 
              Specializing in React, Node.js, and modern web technologies.
            </p>
            <div className="flex gap-4">
              <a 
                href="#projects" 
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                View My Work
              </a>
              <a 
                href="#contact" 
                className="px-6 py-3 border border-gray-300 rounded-lg hover:border-gray-400 transition-colors"
              >
                Contact Me
              </a>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1544256718-3bcf237f3974?auto=format&fit=crop&q=80&w=1000"
              alt="Professional headshot"
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-lg">
              <div className="flex gap-4">
                <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-gray-900">
                  <Github size={24} />
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-gray-900">
                  <Linkedin size={24} />
                </a>
                <a href="mailto:contact@example.com" className="text-gray-600 hover:text-gray-900">
                  <Mail size={24} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Home;